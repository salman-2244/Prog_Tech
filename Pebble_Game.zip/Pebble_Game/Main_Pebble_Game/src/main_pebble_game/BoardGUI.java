/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main_pebble_game;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



public class BoardGUI {
    
    private final JButton[][] allButtons; // 2d to store all the buutons i-e Pebbles
	private final JPanel gameBoard; 
	private final int length;
	private PebbleBoard pBoard;
	
	
	public BoardGUI(int length) {
		
		this.length = length;

		this.pBoard = new PebbleBoard(length);

		
		allButtons = new JButton[length][length]; // Declaring Pebbles as buttons

		gameBoard = new JPanel();

		this.gameBoard.setFocusable(true);

		this.gameBoard.grabFocus();

		gameBoard.addKeyListener(new KeyAction());

		gameBoard.setLayout(new GridLayout(length,length));

		for(int i = 0 ; i < length ; i++) {
			for(int j = 0 ; j < length ; j++) {
				JButton btn = new JButton();
				btn.setFocusable(false);
				btn.setPreferredSize(new Dimension(50,50));
				btn.addActionListener(new ListenToButton(i,j));
				if(pBoard.getPebble(i,j) != null) { 
					pBoard.getPebble(i,j).setPos(i,j); // Setting the Cordinates of Pebbles mean rows and Cols
					btn.setEnabled(true);
					btn.setBackground(pBoard.getPebble(i,j).getColor()); // Setting Background Color of Pebbles
					allButtons[i][j] = btn;
				}else {
					btn.setEnabled(false);
					allButtons[i][j] = btn;
				}
			}
		} 
		for(int i = 0 ; i < length ; i++) {
			for(int j = 0 ; j < length ; j++) {  /// Adding all the buttons to JPanel
				this.gameBoard.add(allButtons[i][j]);
			}
		}

	}
	
	
	public void update() {
		for(int i = 0 ; i < length ; i++) {
			for(int j = 0 ; j < length ; j++) {
				if(pBoard.getPebble(i,j) == null) {
                                    allButtons[i][j].setEnabled(false);
                                    allButtons[i][j].setBackground(null);
                                }
                                else {
                                    pBoard.getPebble(i,j).setPos(i,j);
                                    allButtons[i][j].setBackground(pBoard.getPebble(i,j).getColor());
                                    allButtons[i][j].setEnabled(true);
                                }
			}
		}
		gameOverCheck();
                
	}

	private void gameOverCheck() {
		if(null != pBoard.findWinner()) 
                switch (pBoard.findWinner()) {
            case player1:
                JOptionPane.showMessageDialog(this.gameBoard,
                        "Player 1 Won the Game",
                        "Congratulations!!",
                        JOptionPane.INFORMATION_MESSAGE);
                this.pBoard = new PebbleBoard(this.length);
                this.update();
                break;
            case player2:
                JOptionPane.showMessageDialog(this.gameBoard,
                        "Player 2 Won the Game",
                        "Congratulations!!",
                        JOptionPane.INFORMATION_MESSAGE);
                this.pBoard = new PebbleBoard(this.length);
                this.update();
                break;
            case bothPlayers:
                JOptionPane.showMessageDialog(this.gameBoard,
                        "It is a Tie.",
                        "The Game is DRAW",
                        JOptionPane.INFORMATION_MESSAGE);
                this.pBoard = new PebbleBoard(this.length);
                this.update();
                break;
            default:
                break;
        }
	}

	

	public JPanel getPanel() {return this.gameBoard;}
	
	
		class ListenToButton implements ActionListener {
			int x,y;
			Pebble current;
			ListenToButton(int x, int y){
				this.x = x ; this.y = y;
			}
			@Override
			public void actionPerformed(ActionEvent event) {
				System.out.println("Clicked");
				current = pBoard.getPebble(x, y); 
				//System.out.println(x + ", " + y);
				if(current == null) {
					return;
				}
				pBoard.setSelectedpebble(null);
				if(current.getPlayer() == pBoard.getCurrPlayer()) {///validation if the Right player clicked on his pebble
					pBoard.setSelectedpebble(current);
				}
			}
		}
		
		class KeyAction implements KeyListener{
			@Override
			public void keyPressed(KeyEvent event) {}
			@Override
			public void keyReleased(KeyEvent event) {
				System.out.println("key is Pressed");
				if(pBoard.getSelectedPebble() != null) {
                                    switch (event.getKeyCode()) {
                                        case KeyEvent.VK_UP:
                                            pBoard.shiftPebbles(Directions.North);
                                            break;
                                        case KeyEvent.VK_DOWN:
                                            pBoard.shiftPebbles(Directions.South);
                                            break;
                                        case KeyEvent.VK_RIGHT:
                                            pBoard.shiftPebbles(Directions.East);
                                            break;
                                        case KeyEvent.VK_LEFT:
                                            pBoard.shiftPebbles(Directions.West);
                                            break;
                                        default:
                                            break;
                                    }
                                        
					pBoard.setSelectedpebble(null); // Only if Pebbles are at the corners set them null
					pBoard.nextT();
                                        update();
					
				}
			}
			@Override
			public void keyTyped(KeyEvent event) {}
		}
    
}
