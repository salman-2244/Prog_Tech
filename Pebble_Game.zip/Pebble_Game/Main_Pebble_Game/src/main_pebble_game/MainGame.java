/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main_pebble_game;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
/**
 *
 * @author salman
 */
public class MainGame {

    
        private JFrame frame;
	private BoardGUI gamePlay;
	
	private final int DEFAULT_BOARD_SIZE = 4;
	
	public MainGame() {
		frame = new JFrame("Pebble Game");
		frame.setFocusable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        gamePlay = new BoardGUI(DEFAULT_BOARD_SIZE);
        frame.getContentPane().add(gamePlay.getPanel(), BorderLayout.CENTER);

        JMenuBar menuBar = new JMenuBar();
        menuBar.setFocusable(false);
        frame.setJMenuBar(menuBar);

        JButton exitMenu = new JButton("Exit");
        exitMenu.setFocusable(false);
        menuBar.add(exitMenu);
        exitMenu.addActionListener((ActionEvent event) -> {
            System.exit(0);
                });



        JButton rules = new JButton("Rules");
        rules.setFocusable(false);
        menuBar.add(rules);
        rules.addActionListener((ActionEvent event) -> {
            if (Desktop.isDesktopSupported()) {
                try {
                    File myFile = new File("./rules.txt");
                    Desktop.getDesktop().open(myFile);
                }
                
                catch (IOException e) {
                    System.out.println("File Not Found");
                }
            }   });
     

        menuBar.add(Box.createHorizontalGlue());
       
        int[] boardSizes = new int[]{3, 4, 6};
        for (int boardSize : boardSizes) {
            JButton sizeMenuI = new JButton(boardSize + "x" + boardSize);
            sizeMenuI.setFocusable(false);
            menuBar.add(sizeMenuI);
            sizeMenuI.addActionListener((ActionEvent e) -> {
                frame.getContentPane().remove(gamePlay.getPanel());
                gamePlay = new BoardGUI(boardSize);
                frame.getContentPane().add(gamePlay.getPanel(), BorderLayout.CENTER);
                gamePlay.getPanel().requestFocus();
                frame.pack();
            });
        }
        frame.pack();
        frame.setVisible(true);
	}
	
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
         new MainGame();

    }
    
}
