/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main_pebble_game;

import java.util.ArrayList;
import java.util.Collections;

public class PebbleBoard{
	private int countTurns;
	private Players turn = Players.player1; //Game will always begin with Player1 who has black pebbles
	private final int length;
	private final ArrayList<Pebble> pebblesArr;
	private Pebble selPebble;
	
	
	public PebbleBoard(int length) {

		this.length = length;

		this.countTurns = 0;

		pebblesArr = new ArrayList<Pebble>();
		
		for(int i = 0; i < length; i++) {       // Initialize 2 rows with n pebbles and then shuffle them
			for(int j = 0 ; j < length ; j++) {
				if(i == 0) {
					pebblesArr.add(new Pebble(0,0,Players.player1));//The Coordinates are temp for now. They will be changed later during the buttons initialization
				}else if(i == 2) {
					pebblesArr.add(new Pebble(0,0,Players.player2));
				}else {
					pebblesArr.add(null);
				}
			}
		}
		Collections.shuffle(pebblesArr);
	}

	
	
	/**
	 * @param dir
	 * Take Dirctions From the arrow keys and move the pebbles
	 * accordingly
	 */
	public void shiftPebbles(Directions dir) {
	
		if(dir == Directions.North)
			{
				int row = this.selPebble.getCol(); // rows
				int col = this.selPebble.getRow(); ///col
				this.pebblesArr.set((row) + (col)*length, null);
				while(col > 0 && this.selPebble != null) {
					Pebble tempPebble = this.getPebble(col-1, row);
					this.selPebble.setPos(col-1, row);
					this.pebblesArr.set((row) + (col-1)*length, this.selPebble);
					this.selPebble = tempPebble;
					col--;
				}
			}
		else if(dir == Directions.South)
			{
				int row = this.selPebble.getCol(); ///rows
				int col = this.selPebble.getRow(); ///col
				this.pebblesArr.set((row) + (col)*length, null);
				while(col < (length - 1 ) && this.selPebble != null) {
					Pebble tempPebble = this.getPebble(col+1, row);
					this.selPebble.setPos(col+1, row);
					this.pebblesArr.set((row) + (col+1)*length, this.selPebble);
					this.selPebble = tempPebble;
					col++;
				}
			}
		else if(dir == Directions.East)
			{
				int row = this.selPebble.getCol(); ///rows
				int col = this.selPebble.getRow(); ///col
				this.pebblesArr.set((row) + (col)*length, null);
				while(row < (length - 1 ) && this.selPebble != null) {
					Pebble tempPebble = this.getPebble(col, row+1);
					this.selPebble.setPos(col, row+1);
					this.pebblesArr.set((row+1) + (col)*length, this.selPebble);
					this.selPebble = tempPebble;
					
					row++;
				}
			}
		else if(dir == Directions.West)
			{
				int row = this.selPebble.getCol(); ///rows
				int col = this.selPebble.getRow(); ///col
				this.pebblesArr.set((row) + (col)*length, null);
				while(row > 0 && this.selPebble != null) {
					Pebble tempPebble = this.getPebble(col, row-1);
					this.selPebble.setPos(col, row-1);
					this.pebblesArr.set((row-1) + (col)*length, this.selPebble);
					this.selPebble = tempPebble;
					
					row--;
				}
			}
		
		else{
			
		}
		}
	

	public void nextT() {
		if(turn == Players.player1)
		 {
			turn = Players.player2;
		}
		else {
			turn = Players.player1;
		}

		this.countTurns++;
	}



	public Players findWinner() {
		if(this.countTurns >= length * 5) { 			//after 5*n turns are completed 
			int p1Count = 1;

			int p2Count = 1;

			while(!this.pebblesArr.isEmpty()) {

				Pebble tempPebble = this.pebblesArr.remove(this.pebblesArr.size() - 1); // checking all pebles by removing them from pebbles array
				if(tempPebble == null) 
				{
					continue;
				}
				if(tempPebble.getPlayer() == Players.player1) 
				{
					p1Count++;
				}
				else if(tempPebble.getPlayer() == Players.player2) 
				{
					p2Count++;
				}
                         System.out.println(p1Count);
                         System.out.println(p2Count);
                         System.out.println( "count turns" + countTurns);
			}
			if(p1Count > p2Count) 
			{
				return Players.player1;
			}
			else if(p1Count < p2Count)
			{
				return Players.player2;
                                
			}
                        else if (p1Count == p2Count)
                        {
                            return Players.bothPlayers;
                        }
                         
		}
              
                
		else if(this.countTurns < length * 5) { // If turns are smaller than 5*n and one Player kick all the pebbles out
			int p1Count = 0;

			int p2Count = 0;

			int inderow = -1; // to get the pebbles from 0 till length*length -1

			while(this.pebblesArr.size() - 1 - inderow > 0) {
				inderow++;
				Pebble tempPebble = this.pebblesArr.get(inderow);
				if(tempPebble == null) 
				{
					continue;
				}
				if(tempPebble.getPlayer() == Players.player1) 
				{
					p1Count++;
				}

				else if(tempPebble.getPlayer() == Players.player2)
				 {
					p2Count++;
				}
			}
			if(p1Count == 0 && p2Count > 0 ) 
			{
				return Players.player2;
			}
			else if(p2Count == 0 && p1Count > 0)
			{
				return Players.player1;
			}
		}
		return null;
	}

	public Players getCurrPlayer()
	 {
		return this.turn;
	 }

	public Pebble getPebble(int row, int y) 
	{
		 return this.pebblesArr.get(y + row * length);
	}
	public Pebble getSelectedPebble() 
	{
		 return this.selPebble;
	}
	
	public void setSelectedpebble(Pebble peb)
	{
		this.selPebble = peb;
	}
}