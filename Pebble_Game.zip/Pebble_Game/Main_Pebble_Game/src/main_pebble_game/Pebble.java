/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main_pebble_game;

import java.awt.Color;

public class Pebble {
	private final Players player;
	private int row,col;
	private Color color;
	
	
	public Pebble(int row , int col, Players player) {   // Constructor
		this.player  = player;
		this.row = row;
		this.col = col;
		
		if(this.player == Players.player1) 
		{
			color = Color.BLACK;
		}  
		else if (this.player == Players.player2)
		{
			color = Color.WHITE;
		}
		
	} 
	
	
	public void setPos(int row,int col) 
	{ this.row = row;
	  this.col = col;
	}
	public int getRow() {return this.row;}

	public int getCol() {return this.col;}

	public Players getPlayer() {return this.player;}

	public Color getColor() {return this.color;}
	
	
}

