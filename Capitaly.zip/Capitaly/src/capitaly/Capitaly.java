/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package capitaly;  
import exceptions.NegativeNumberException;
import exceptions.EmptyFileException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;


/**
 *
 * @author YAugm3
 */
public class Capitaly {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         try {
            System.out.println("Please Enter Number of Rounds?");
            Scanner sc = new Scanner(System.in);
            int input = sc.nextInt();
            InputFromFile data = new InputFromFile();
            data.readData("./src/capitaly/InputFiles/test.txt");
            data.readDice("./src/capitaly/InputFiles/dice.txt", input);
            
         } catch(FileNotFoundException e){
             System.out.println("File not found!");  //handeling Exceptions
         } catch (EmptyFileException e){
             System.out.println("Empty File!");
         }
         catch(InputMismatchException e){
             System.out.println("Something Wrong with Format of File");
         }
         catch(NegativeNumberException Negative){
             System.out.println("Negative or Zero Number is in the File");
             
         }
         catch( NoSuchElementException element){
             System.out.println("No Such thing exist in File");
             
         }
       
        catch(Exception e){
             System.out.println("No of rounds is out of bound!");
             
         }
         
          
    }
}

