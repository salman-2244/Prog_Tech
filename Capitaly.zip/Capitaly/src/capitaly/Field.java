/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capitaly;

/**
 *
 * @author YAugm3
 */
public class Field {
    protected String type;
    protected String status;
    protected Players landLord;

    public String getType() {
        return type;
    }

    public Field(String type) {
        this.type = type;
        this.status = "free";
        this.landLord = null;
    }

   
    public String isStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getPrice() {  // to be overriden in child classes
        return 0;
    }


    public Players getLandLord() {
        return landLord;
    }

    public void setLandLord(Players landLord) {
        this.landLord = landLord;
    }
    
    public void landedOn(Players p){} // to be overridden
    {
    }
    
    @Override
    public String toString()
    {
        return " Land = [" + type + " ]  Owner Name = [ " + (status != "free" ? landLord.getName() : "null") + " ] status of Property = [ " +
                status + " ]  " ;
        
    }
 
}
